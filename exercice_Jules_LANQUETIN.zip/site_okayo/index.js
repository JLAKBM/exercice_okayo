const express = require("express")

const app = express()
const PORT = 8080

const router = require("./router.js")

// app.get("/", (_,res) => {
//     const indexHTML = fs.readFileSync(__dirname + "/views/creation.html", "utf8")

//     res.send(indexHTML)
// })

app.use(express.json());
app.use(router)
app.use("/css", express.static(__dirname + "/css/"))
app.use("/medias", express.static(__dirname + "/medias/"))
app.use("/javascript", express.static(__dirname + "/javascript/"))

app.listen(PORT, () => {
    console.log("Server online.")
})