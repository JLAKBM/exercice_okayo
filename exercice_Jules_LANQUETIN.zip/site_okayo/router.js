const express = require("express")
const fs = require("fs")
const mysql = require("mysql")

const router = express.Router()

router.get("/", (_,res) => {
    const indexHTML = fs.readFileSync(__dirname + "/views/creation.html", "utf8")

    res.send(indexHTML)
})

router.get("/creation", (_,res) => {
    const indexHTML = fs.readFileSync(__dirname + "/views/creation.html", "utf8")

    res.send(indexHTML)
})

router.post("/save-invoice", (req,res) => {

    const connection = mysql.createConnection({
        host: "localhost",
        user: "root",
        password: "",
        database: "gestionfactures",
    });
        
    connection.connect((err) => {
        if (err) {
            console.error("Impossible de se connecter à la base de données " + err.stack)
            res.status(500).json({message: "Impossible de se connecter à la base de données."})
            return;
        }
    });

    let query = "INSERT INTO facture(date_creation, date_echeance, montant_HT_total, montant_TVA_total, montant_TTC_total, id_client) VALUES ('" + req.body.invoiceData['date-facturation'] + "','" + req.body.invoiceData['date-echeance'] + "','" + req.body.invoiceData['totalHT'] + "','" + req.body.invoiceData['totalTVA'] + "','" + req.body.invoiceData['totalTTC'] + "','" + req.body.invoiceData['client-code'] + "');"
    connection.query(query, (err, rows, fields) => {
        if (err) throw err;
    })

    for (let index = 0; index < req.body.invoiceRowsData.length; index++) {
        const invoiceRow = req.body.invoiceRowsData[index];
        
        query = "INSERT INTO lignefacture(designation, prix_unitaire_HT, quantite, taux_TVA, montant_HT, id_facture, id_produit) VALUES ('" + invoiceRow["produit-designation"] + "','" + invoiceRow["produit-prix"] + "','" + invoiceRow["produit-quantite"] + "','" + invoiceRow["produit-tva"] + "','" + invoiceRow["totalHT"] + "',(SELECT MAX(id_facture) FROM facture),'1')"
        connection.query(query, (err, rows, fields) => {
            if (err) throw err;
        })
    }
    
    connection.end();

})

router.get("/consultation", (_,res) => {
    const indexHTML = fs.readFileSync(__dirname + "/views/consultation.html", "utf8")

    res.send(indexHTML)
})

module.exports = router