-- Création de la base de données
CREATE DATABASE IF NOT EXISTS GestionFactures;
USE GestionFactures;

-- Création de la table Client
CREATE TABLE Client (
    id_client VARCHAR(11) PRIMARY KEY,
    nom VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    adresse TEXT NOT NULL
);

-- Création de la table TVA
CREATE TABLE TVA (
    id_TVA INT PRIMARY KEY AUTO_INCREMENT,
    nom VARCHAR(50) NOT NULL,
    taux_TVA DECIMAL(5, 2) NOT NULL,
    date_debut_validite DATE NOT NULL,
    date_fin_validite DATE
);

-- Création de la table CatalogueProduit
CREATE TABLE Produit (
    id_produit INT PRIMARY KEY AUTO_INCREMENT,
    designation VARCHAR(100) NOT NULL,
    prix_unitaire_HT DECIMAL(10, 2) NOT NULL,
    id_TVA INT,
    FOREIGN KEY (id_TVA) REFERENCES TVA(id_TVA)
);

-- Création de la table Facture
CREATE TABLE Facture (
    id_facture INT PRIMARY KEY AUTO_INCREMENT,
    date_creation DATE NOT NULL,
    date_echeance DATE NOT NULL,
    montant_HT_total DECIMAL(10, 2) NOT NULL,
    montant_TVA_total DECIMAL(10, 2) NOT NULL,
    montant_TTC_total DECIMAL(10, 2) NOT NULL,
    id_client VARCHAR(11),
    FOREIGN KEY (id_client) REFERENCES Client(id_client)
);

-- Création de la table LigneFacture
CREATE TABLE LigneFacture (
    id_ligne_facture INT PRIMARY KEY AUTO_INCREMENT,
    designation VARCHAR(100) NOT NULL,
    prix_unitaire_HT DECIMAL(10, 2) NOT NULL,
    quantite INT NOT NULL,
    taux_TVA DECIMAL(5, 2) NOT NULL,
    montant_HT DECIMAL(10, 2) NOT NULL,
    id_facture INT,
    id_produit INT,
    FOREIGN KEY (id_facture) REFERENCES Facture(id_facture),
    FOREIGN KEY (id_produit) REFERENCES Produit(id_produit)
);
