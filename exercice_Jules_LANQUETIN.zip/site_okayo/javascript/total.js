function totalTVA() {
    let TVArateNotNullElements = Object.values(document.querySelectorAll('input[name="produit-tva"]')).filter((input) => parseInt(input.value) > 0);
    let TVAratesNotNull = []
    let TVAratesNotNullSubtotals = {}

    for (let index = 0; index < TVArateNotNullElements.length; index++) {
        const TVArate = parseInt(TVArateNotNullElements[index].value)*0.01;
        const totalHT = parseInt(TVArateNotNullElements[index].parentNode.lastChild.innerText);
        
        // Sous-totaux TVA par produit
        TVAratesNotNull.push(
            { 
                "TVArate" : TVArate,
                "subtotal": Math.round(TVArate*totalHT*1000)/1000
            }
        )

        // Sous-totax TVA par taux de TVA
        TVAratesNotNullSubtotals[TVArate] ? TVAratesNotNullSubtotals[TVArate] += Math.round(TVArate*totalHT*1000)/1000 : TVAratesNotNullSubtotals[TVArate] = Math.round(TVArate*totalHT*1000)/1000
    }

    const totalTVA = Math.round(TVAratesNotNull.reduce((accumulator, currentSubtotal) => accumulator + currentSubtotal.subtotal,0)*1000)/1000;

    return { "totalTVA" : totalTVA, "TVAratesNotNullSubtotals" : TVAratesNotNullSubtotals }
}

function getTotalHT() {
    let subtotalHTElements = Object.values(document.querySelectorAll('.row p'))
    let totalHT = 0

    for (let index = 0; index < subtotalHTElements.length; index++) {
        const subtotalHT = parseFloat(subtotalHTElements[index].innerText);
        
        totalHT += subtotalHT
    }

    return Math.round(totalHT*1000)/1000
}

function displayTotalTVA() {
    const dataTVA = totalTVA()

    document.querySelector("#totalTVA").innerText = dataTVA.totalTVA + "€";

    let totalTVAElement = document.querySelector(".total > div:nth-of-type(1)")
    totalTVAElement.innerHTML = ""

    for (const [TVArate, subtotal] of Object.entries(dataTVA.TVAratesNotNullSubtotals)) {
        let subtotalTVALabel = document.createElement("p")
        subtotalTVALabel.innerText = "Total TVA " + Math.round(TVArate*100000)/1000 + "%"

        let subtotalTVAValue = document.createElement("p")
        subtotalTVAValue.innerText = subtotal + "€"

        let subtotalTVAElement = document.createElement("div")
        subtotalTVAElement.appendChild(subtotalTVALabel)
        subtotalTVAElement.appendChild(subtotalTVAValue)
        
        totalTVAElement.appendChild(subtotalTVAElement)
    }
}

function displayTotalHT() {
    let totalHT = getTotalHT()
    document.querySelector("#totalHT").innerText = totalHT + "€"

    displayTotalTTC()
}

function displayTotalTTC() {
    let totalTVA = parseFloat(document.querySelector('#totalTVA').innerText)
    let totalHT = parseFloat(document.querySelector('#totalHT').innerText)

    document.querySelector("#totalTTC").innerText = Math.round((totalHT+totalTVA)*1000)/1000 + "€"
}