function displaySubtotalHT(element) {
    let rowElement = element.parentNode
    let puht = parseFloat(rowElement.children[2].value)
    let quantity = parseInt(rowElement.children[3].value)
    rowElement.children[4].innerText = Math.round(puht*quantity*1000)/1000

    displayTotalTVA()
    displayTotalHT()
    getInvoiceRows()
}

function createProductElement(button) {
    let rowElement = document.createElement("div")
    rowElement.className = "row"
    rowElement.title = "Appuyer sur le bouton droit de la souris pour supprimer ce produit de la facture."
    rowElement.addEventListener("contextmenu", (e) => {
        e.preventDefault();

        if (window.confirm("Voulez-vous vraiment supprimer ce produit de la facture ?")) {
            rowElement.remove()
            displayTotalTVA()
            displayTotalHT()
        }
    })

    let childrenAttributes = [
        {
            element:"input",
            type:"text",
            name:"produit-designation",
            placeholder:"Désignation du produit"
        },
        {
            element:"input",
            type:"number",
            name:"produit-tva",
            value:"0",
            oninput: "displayTotalTVA()"
        },
        {
            element:"input",
            type:"number",
            name:"produit-prix",
            value:"0",
            oninput: "displaySubtotalHT(this)"
        },
        {
            element:"input",
            type:"number",
            name:"produit-quantite",
            value:"0",
            oninput: "displaySubtotalHT(this)"
        },
        {
            element:"p",
            innerText:"0"
        },
    ]

    for (let index = 0; index < childrenAttributes.length; index++) {
        const childAttributes = childrenAttributes[index]
        let childElement = document.createElement(childAttributes.element)


        for (const [key, value] of Object.entries(childAttributes)) {
            if (key != "element" && key != "innerText") {
                childElement.setAttribute(key, value)
            }
            else {
                childElement.innerText = "0"
            }
        }
        
        rowElement.appendChild(childElement)
    }

    button.parentNode.insertBefore(rowElement, button)
}