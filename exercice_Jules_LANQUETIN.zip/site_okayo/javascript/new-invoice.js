function getInvoiceData() {
  let invoiceInputs = document.querySelectorAll(".invoice-data")
  let invoiceData = {}

  for (let index = 0; index < invoiceInputs.length; index++) {
    const input = invoiceInputs[index];

    invoiceData[input.name] = input.value
  }

  invoiceData['totalHT'] = getTotalHT()
  invoiceData['totalTVA'] = totalTVA().totalTVA
  invoiceData['totalTTC'] = Math.round((invoiceData['totalHT']+invoiceData['totalTVA'])*1000)/1000

  return invoiceData
}

function getInvoiceRows() {
  let invoiceRows = document.querySelectorAll(".row")
  let invoiceRowsData = []

  for (let index = 0; index < invoiceRows.length; index++) {
    const rowChildren = invoiceRows[index].children;
    let currentRowData = {}

    for (let index = 0; index < rowChildren.length; index++) {
      const child = rowChildren[index];
      
      if (child.name) {
        currentRowData[child.name] = child.value
      }
      else {
        currentRowData["totalHT"] = parseFloat(child.innerText)
      }
      
    }

    invoiceRowsData.push(currentRowData)
    
  }

  return invoiceRowsData
}

async function sendInvoice() {

    try {
      const reponse = await fetch("/save-invoice", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          invoiceData : getInvoiceData(),
          invoiceRowsData : getInvoiceRows()
        }),
      });
  
      const res = await reponse.json();
      
      console.log(res.message)
    } catch (erreur) {
        console.log(erreur)
    }
}